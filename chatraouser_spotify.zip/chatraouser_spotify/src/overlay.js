const discoverBtn = document.getElementById("discoverBtn");
const reloadBtn = document.getElementById("reloadBtn");
const backBtn = document.getElementById("backBtn");

const discoveryScreen = document.getElementById("discoveryScreen");
const albumImage = document.getElementById("albumImage");
const songTitle = document.getElementById("songTitle");
const artistName = document.getElementById("artistName");
const audioPlayer = document.getElementById("audioPlayer");
const loading = document.getElementById("loading");

const passBtn = document.getElementById("passBtn");
const likeBtn = document.getElementById("likeBtn");
const shuffleBtn = document.getElementById("shuffleBtn");
const savedList = document.getElementById("savedList");

let tracks = [];
let currentTrack = null;
let savedTracks = [];

const keywords = [
  "kpop",
  "indie",
  "rnb",
  "dream pop",
  "city pop",
  "electronic",
  "jazz",
  "lofi",
  "rock",
  "dance",
  "newjeans",
  "aespa",
  "iu",
  "bigbang"
];

function setLoading(value) {
  loading.classList.toggle("show", value);
}

function shuffle(array) {
  return [...array].sort(() => Math.random() - 0.5);
}

async function fetchTracks() {
  setLoading(true);

  const keyword = keywords[Math.floor(Math.random() * keywords.length)];

  try {
    const response = await fetch(
      `https://api.deezer.com/search?q=${encodeURIComponent(keyword)}&limit=50`
    );

    const data = await response.json();

    tracks = shuffle(data.data || []).filter(track => track.preview);
  } catch (error) {
    console.error(error);
    tracks = [];
  }

  setLoading(false);
}

async function showRandomTrack() {
  if (tracks.length === 0) {
    await fetchTracks();
  }

  if (tracks.length === 0) {
    songTitle.innerText = "음악을 불러오지 못했어요";
    artistName.innerText = "네트워크 연결을 확인해주세요";
    return;
  }

  const index = Math.floor(Math.random() * tracks.length);
  currentTrack = tracks[index];

  albumImage.src = currentTrack.album.cover_big || currentTrack.album.cover_medium;
  songTitle.innerText = currentTrack.title;
  artistName.innerText = currentTrack.artist.name;
  audioPlayer.src = currentTrack.preview;

  audioPlayer.play().catch(() => {
    // 브라우저 정책상 자동재생이 막히면 사용자가 재생 버튼을 누르면 됨.
  });

  const card = document.getElementById("musicCard");
  card.style.animation = "none";
  card.offsetHeight;
  card.style.animation = "pop .32s ease";
}

function renderSaved() {
  if (savedTracks.length === 0) {
    savedList.innerHTML = "<p>아직 저장한 곡이 없어요.</p>";
    return;
  }

  savedList.innerHTML = "";

  savedTracks.forEach(track => {
    const item = document.createElement("div");
    item.className = "saved-item";

    item.innerHTML = `
      <img src="${track.album.cover_small}">
      <div>
        <strong>${track.title}</strong>
        <span>${track.artist.name}</span>
      </div>
    `;

    savedList.appendChild(item);
  });
}

discoverBtn.addEventListener("click", async () => {
  discoveryScreen.classList.remove("hidden");
  window.chatraouser.enterDiscovery();
  await showRandomTrack();
});

backBtn.addEventListener("click", () => {
  discoveryScreen.classList.add("hidden");
  audioPlayer.pause();
  window.chatraouser.exitDiscovery();
});

reloadBtn.addEventListener("click", () => {
  window.chatraouser.reloadSpotify();
});

passBtn.addEventListener("click", showRandomTrack);

shuffleBtn.addEventListener("click", async () => {
  tracks = [];
  await showRandomTrack();
});

likeBtn.addEventListener("click", async () => {
  if (currentTrack) {
    savedTracks.unshift(currentTrack);
    renderSaved();
  }

  await showRandomTrack();
});

renderSaved();
