const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("chatraouser", {
  enterDiscovery: () => ipcRenderer.send("enter-discovery"),
  exitDiscovery: () => ipcRenderer.send("exit-discovery"),
  reloadSpotify: () => ipcRenderer.send("reload-spotify")
});
