# 찾으라우저 🎧

실제 Spotify 웹사이트를 기본 화면으로 띄우고, `찾아보자!` 버튼을 누르면 Tinder 스타일 랜덤 음악 탐험 모드로 전환되는 Electron 데모입니다.

## 실행 방법

```bash
npm install
npm start
```

## 구조

- 일반 모드: 실제 `https://open.spotify.com` BrowserView 표시
- 탐험 모드: BrowserView 숨김, 랜덤 음악 카드 표시
- 음악 데이터/재생: Deezer 공개 API 기반 30초 preview 재생

Spotify Web API는 현재 Premium 제한으로 막힐 수 있어서, 데모 안정성을 위해 랜덤 탐험 모드는 Deezer API를 사용했습니다.
