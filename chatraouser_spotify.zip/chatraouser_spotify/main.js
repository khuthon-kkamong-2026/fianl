const { app, BrowserWindow, BrowserView, ipcMain } = require("electron");
const path = require("path");

let win;
let spotifyView;
const TOP_BAR_HEIGHT = 76;

function setSpotifyBounds() {
  if (!win || !spotifyView) return;

  const { width, height } = win.getContentBounds();

  spotifyView.setBounds({
    x: 0,
    y: TOP_BAR_HEIGHT,
    width,
    height: height - TOP_BAR_HEIGHT
  });
}

function createWindow() {
  win = new BrowserWindow({
    width: 1500,
    height: 950,
    minWidth: 1000,
    minHeight: 720,
    backgroundColor: "#111111",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  spotifyView = new BrowserView({
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true
    }
  });

  win.setBrowserView(spotifyView);
  setSpotifyBounds();

  spotifyView.setAutoResize({
    width: true,
    height: true
  });

  spotifyView.webContents.loadURL("https://open.spotify.com");

  win.loadFile(path.join(__dirname, "src", "overlay.html"));

  win.on("resize", setSpotifyBounds);
}

ipcMain.on("enter-discovery", () => {
  if (win && spotifyView) {
    win.removeBrowserView(spotifyView);
  }
});

ipcMain.on("exit-discovery", () => {
  if (win && spotifyView) {
    win.setBrowserView(spotifyView);
    setSpotifyBounds();
  }
});

ipcMain.on("reload-spotify", () => {
  if (spotifyView) spotifyView.webContents.reload();
});

app.whenReady().then(createWindow);

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
